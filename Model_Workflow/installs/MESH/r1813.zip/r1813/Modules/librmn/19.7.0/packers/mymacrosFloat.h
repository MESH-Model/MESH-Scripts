#define FLOAT_4_8 float
#define compact_FLOAT_4_8 compact_float


static   int okBit            = 32;  
static   int geneticOn        = 1;
static   int token4BitTestOn  = 0;
static   int token16BitTestOn = 0;
static   int token24BitTestOn = 0;
static   int token32BitTestOn = 0;
static   int stabilityOn      = 1;
static   int strideTestOn     = 1;
static   int errorTestOn      = 1;
static   int inPlaceTestOn    = 0;
static   int indexTestOn      = 1;
static   int testOfDoubleInPlace = 0;
static   int largeTestOn  = 1;



