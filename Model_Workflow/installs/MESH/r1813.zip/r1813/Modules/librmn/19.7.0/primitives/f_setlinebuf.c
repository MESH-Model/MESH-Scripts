#include <rpnmacros.h>
#include <stdio.h>
void f77name(f_setlinebuf)()
{
  setlinebuf(stdout);
}