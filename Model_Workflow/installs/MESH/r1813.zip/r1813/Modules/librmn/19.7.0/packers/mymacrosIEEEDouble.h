#define FLOAT_4_8 double
#define compact_IEEEblock_FLOAT_4_8 compact_IEEEblock_double


static   int okBit            = 27;  
static   int geneticOn        = 1;
static   int token4BitTestOn  = 0;
static   int token16BitTestOn = 0;
static   int token24BitTestOn = 0;
static   int token32BitTestOn = 0;
static   int stabilityOn      = 0;
static   int strideTestOn     = 0;
static   int errorTestOn      = 0;
static   int inPlaceTestOn    = 0;
static   int indexTestOn      = 0;
static   int testOfDoubleInPlace = 0;
static   int largeTestOn  = 0;



