#define FLOAT_4_8 double
#define compact_FLOAT_4_8 compact_double



static   int okBit            = 27;  
static   int geneticOn        = 0;
static   int token4BitTestOn  = 0;
static   int token16BitTestOn = 0;
static   int token24BitTestOn = 0;
static   int token32BitTestOn = 0;
static   int stabilityOn      = 1;
static   int strideTestOn     = 1;
static   int errorTestOn      = 1;
static   int inPlaceTestOn    = 0;
static   int indexTestOn      = 1;

static   int testOfDoubleInPlace = 1;


